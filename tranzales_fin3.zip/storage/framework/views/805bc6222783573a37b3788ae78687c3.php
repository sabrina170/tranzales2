<div class="modal fade" id="editcierre2<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalScrollableTitle">Cierre</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form action="<?php echo e(route('edit-cierre')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <div class="row">
                       <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <?php if($item->id==$doc->id_cierre): ?>
                           <div class="col-md-4 col-12">
                            <div class="mb-1">
                                <label class="form-label" for="first-name-column">
                                    Fecha de Facturación </label>
                                <input type="date" class="form-control" name="fecha_fac" value="<?php echo e($item->fecha_fac); ?>" required>
                            </div>
                        </div>
                        <div class="col-md-6 col-12">
                            <div class="mb-1">
                                <label class="form-label" for="first-name-column">
                                    N° Facturación</label>
                                <input type="text" class="form-control" name="n_fac" value="<?php echo e($item->n_fac); ?>" required>
                            </div>
                        </div>
                           <?php else: ?>
                               
                           <?php endif; ?>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
                        
                    </div>
                </div>

                <div class="modal-footer">
                    <input type="hidden" name="id_soli" value="<?php echo e($doc->id); ?>" readonly>
                    <input type="hidden" name="id_cierre" value="<?php echo e($doc->id_cierre); ?>" readonly>
                    <button type="submit" class="btn btn-success  waves-effect waves-float waves-light" 
                    name="accion" value="finalizar">Actualizar</button>
                </div>
            </form>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tranzales2\resources\views/admin/modals/ActualizarCierre2.blade.php ENDPATH**/ ?>