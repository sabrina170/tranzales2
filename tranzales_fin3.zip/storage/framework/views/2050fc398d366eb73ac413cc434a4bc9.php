<!-- MENU -->
<?php $__env->startSection('content'); ?>

<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">Modulo</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="">Solicitudes</a>
                        </li>
                        <li class="breadcrumb-item active">Detalle
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    
    <?php if(Auth::user()->tipo==1 || Auth::user()->tipo==2): ?>
    <div class="content-header-left text-md-end col-md-3 col-12 d-md-block d-none">
        <div class="mb-1 breadcrumb-left">
            <a href="<?php echo e(route('admin.solicitudes.nueva-solicitud')); ?>" type="button" class="btn btn-danger waves-effect waves-float waves-light">Agregar +</a>
    
        </div>
       
    </div>
    <?php else: ?>
    <?php endif; ?>
</div>


<div class="content-body">
    <?php if(Auth::user()->tipo==1 || Auth::user()->tipo==2): ?>
    <div class="table-responsive">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm" 
                    id="tablamaestro" style="display: none ">
                        <thead class="text-center">
                            <tr>
                                
                                
                                <th style="font-size: 10px">FECHA <br> TRASLADO</th>
                                <th style="font-size: 10px">CLIENTE</th>
                                <th style="font-size: 10px">HORA <br> EN GRANJA</th>
                                <th style="font-size: 10px">CANTIDAD <br> TOTAL</th>
                                <th style="font-size: 10px">ORIGEN</th>
                                <th style="font-size: 10px">ORIGEN 2</th>
                                <th style="font-size: 10px;width: 40px">DESTINOS</th>
                                <th style="font-size: 10px;width: 40px">UNIDAD</th>
                                <th style="font-size: 10px;width: 40px">PLACA</th>
                                <th style="font-size: 10px;width: 40px">CHOFER</th>
                                <th style="font-size: 10px;width: 40px">AYUDANTE</th>
                                
                                <th style="font-size: 10px;width: 40px">JORNADA DE AYUDANTE</th>
                                <th style="font-size: 10px;width: 40px">LAVADO</th>
                                <th style="font-size: 10px;width: 40px">N° COMPROBANTE</th>
                                <th style="font-size: 10px;width: 40px">INDICACIONES ESPECIALES</th>
                                <th style="font-size: 10px;width: 40px">OBSERVACIONES FINAL DEL VIAJE</th>
                                <th style="font-size: 10px">HORA DE SALIDA EN COCHERA</th>
                                <th style="font-size: 10px;width: 40px">GUIA DE TERCEROS</th>
                                <th style="font-size: 10px;width: 40px">GUIA DE TRANSPORTISTA</th>
                                <th style="font-size: 10px;width: 40px">GUIA DE CLIENTE </th>

                                <th style="font-size: 10px;width: 40px">REVISADO POR</th>
                                <th style="font-size: 10px;width: 40px">PAGO DE CHOFER</th>
                                <th style="font-size: 10px;width: 40px">PAGO AYUDANTE</th>
                                <th style="font-size: 10px;width: 40px">DEVOLUCION DE GASTOS AL CONDUCTOR (**)</th>
                                <th style="font-size: 10px;width: 40px">DEVOLUCION PTA HERMOSA (GLH)</th>
                                <th style="font-size: 10px;width: 40px">CAJA CHICA - MIGUEL</th>
                                <th style="font-size: 10px;width: 40px">CAJA GT</th>
                                <th style="font-size: 10px;width: 40px">PEAJE TOTAL</th>
                                <th style="font-size: 10px;width: 40px">PEAJE E-PASS</th>
                                <th style="font-size: 10px;width: 40px">PEAJE PEX</th>
                                <th style="font-size: 10px;width: 40px">PEAJE EASY WAY</th>
                                <th style="font-size: 10px;width: 40px">OTRO PEAJES(**)</th>
                                <th style="font-size: 10px;width: 40px">BALANZA2</th>

                                <th style="font-size: 10px;width: 40px">GASTOS (EXTRAS)(**)</th>
                                <th style="font-size: 10px;width: 40px">CONTEXTO GASTO EXTRA</th>
                                <th style="font-size: 10px;width: 40px">LAVADERO (INICIO DE LAVADO)</th>
                                <th style="font-size: 10px;width: 40px">TURNO</th>
                                <th style="font-size: 10px;width: 40px">COSTO LAVADO Y DESINFECCION</th>

                                <th style="font-size: 10px;width: 40px">CANTIDAD DE COMBUSTIBLE RECARGADO</th>
                                <th style="font-size: 10px;width: 40px">PRECIO DEL COMBUSTIBLE</th>
                                <th style="font-size: 10px;width: 40px">COMBUSTIBLE RECARGADO</th>
                                <th style="font-size: 10px;width: 40px">CANTIDAD DE COMBUSTIBLE CONSUMIDO</th>
                                <th style="font-size: 10px;width: 40px">COMBUSTIBLE CONSUMIDO</th>
                                <th style="font-size: 10px;width: 40px">GASTOS TOTAL</th>
                                <th style="font-size: 10px;width: 40px">FECHA FACTURACION</th>
                                <th style="font-size: 10px;width: 40px">N° FACTURA</th>
                                <th style="font-size: 10px;width: 40px">FACTURADO</th>

                                <th style="font-size: 10px;width: 40px">KM INICIAL</th>
                                <th style="font-size: 10px;width: 40px">HORA INICIAL</th>
                                <th style="font-size: 10px;width: 40px">KM FINAL</th>
                                <th style="font-size: 10px;width: 40px">HORA FINAL</th>
                                <th style="font-size: 10px;width: 40px">KM RECORRIDO</th>
                                <th style="font-size: 10px;width: 40px">OBSERVACIONES</th>
                                
                             
                                <th style="font-size: 10px">ESTADO</th>

                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr style="font-size: 12px;"> 
                                
                                <?php
                                $fecha= $doc->fecha_traslado;
                                $date = new DateTime($fecha);    
                                ?>
                                <td><strong><?php echo e($date->format('d-m-Y')); ?></strong></td>
                                <td style="font-size: 12px"><strong><?php echo e($doc->nombre_cli); ?></strong></td>
                                <td><strong><?php echo e($doc->hora); ?></strong></td>
                                <td><?php echo e($doc->cantidad); ?></td>
                                <td><?php echo e($doc->referencia_cli); ?></td>
                                <td> -</td>
                                <td> 
                                    <?php $__currentLoopData = json_decode($doc->destinos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($des->id==$item): ?>
                                        <?php echo e($des->referencia); ?> <br>
                                       
                                        <?php else: ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    ?>
                                </td>
                                
                               
                                    <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                        <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($pla->id ==$doc->id_plani): ?>
                                                    <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($uni->id==$pla->id_unidad): ?>
                                                        
                                                       <td>  <?php echo e($uni->unidad); ?> </td>
                                                       <td>  <?php echo e($uni->placa); ?> </td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                    <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($ch->id==$pla->id_chofer): ?>
                                                          <td>  <?php echo e($ch->nombres_cho); ?> <br> <?php echo e($ch->apellidos_cho); ?></td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                   
                                                <?php else: ?>
                                                <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                   

                                    <?php endif; ?>
                                <td>
                                    <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                        <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($pla->id ==$doc->id_plani): ?>
                                                        <?php $__currentLoopData = $ayudantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ayu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($ayu->id==$pla->choferes): ?>
                                                            <?php echo e($ayu->nombres_cho); ?> <?php echo e($ayu->apellidos_cho); ?>

                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    - <strong><?php echo e($pla->tipo_des); ?></strong>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    -
                                    <?php endif; ?>
                                </td>
                                <td>-</td>
                                <td><?php echo e($doc->lavado); ?></td>
                                <td><?php echo e($doc->comprobante); ?></td>
                                <td>
                                    <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                        <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($pla->id ==$doc->id_plani): ?>
                                                 <?php echo e($pla->observaciones); ?>

                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    -
                                    <?php endif; ?>
                                </td>
                                <td>-</td>
                                
                                
                                <td><?php echo e($doc->hora_cochera); ?></td>
                                <td>-</td>
                               
                                    <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <?php if($doc->id_cierre==$item->id): ?>
                                                              <?php
                                                            $datos_n_guias = json_decode($item->n_guias, true);
                                                            $datos_n_remision = json_decode($item->n_remision, true);
                                                            ?>
                                                <td>
                                                    <?php $__currentLoopData = $datos_n_guias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item); ?> <br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                <td>
                                                    <?php $__currentLoopData = $datos_n_remision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item2); ?> <br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                        <?php else: ?>
                                        <td>-</td>
                                        <td>-</td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
                                
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>
                                    <?php if($doc->id_peaje==0): ?>
                                    0.00
                                    <?php else: ?>
                                        <?php $__currentLoopData = $peajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <?php if($doc->id_peaje==$item->id): ?>
                                                <?php echo e($item->costo_total); ?>  
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                <td>0.00</td>
                                <td>0.00</td>
                                <td>0.00</td>
                                <td>0.00</td>
                                <td>
                                    <?php if($doc->id_balanza==0): ?>
                                    0.00
                                    <?php else: ?>
                                        <?php $__currentLoopData = $balanzas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <?php if($doc->id_balanza==$ba->id): ?>
                                                <?php echo e($ba->costo_total); ?>  
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endif; ?>
                                </td>
                                
                                <td>0.00</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                
                                <?php if($doc->id_combustible==0): ?>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <?php else: ?>
                                        <?php $__currentLoopData = $combustibles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $co): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        
                                            <?php if($doc->id_combustible==$co->id): ?>
                                            <td>
                                                <?php echo e($co->cant_1re); ?> <br>
                                                <?php echo e($co->cant_2re); ?> 
                                                
                                            </td>
                                            <td>
                                                <?php echo e($co->precio_1re); ?> <br>
                                                <?php echo e($co->precio_2re); ?> 
                                            </td>
                                            <td>
                                                <?php echo e($co->recarga1); ?> <br>
                                                <?php echo e($co->recarga2); ?> 
                                            </td>
                                            <td>-</td>
                                            <td>-</td>
                                            <td>-</td>
                                            <td><?php echo e($co->fecha_fac); ?></td>
                                            <td><?php echo e($co->n_fac); ?></td>
                                            <td>-</td>  
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                <?php if($doc->id_cierre==0): ?>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <td>-</td>
                                <?php else: ?>
                                        <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cie): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                       
                                            <?php if($doc->id_cierre==$cie->id): ?>
                                            <td><?php echo e($cie->km_inicial); ?> </td>
                                            <td>-</td>
                                            <td><?php echo e($cie->km_final); ?> </td>
                                            <td>-</td>
                                            <td>-</td>
                                            <td>-</td>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php endif; ?>
                                
                                
                                <td>
                                    <?php if($doc->estado==1): ?>
                                    <span class="badge bg-danger">Creado</span>
                                    <?php elseif($doc->estado==3): ?>
                                    <span class="badge bg-warning">Confirmado</span>
                                    <?php elseif($doc->estado==4): ?>
                                    <span class="badge bg-info">Finalizado</span>
                                    <?php elseif($doc->estado==5): ?>
                                    <span class="badge bg-primary">Facturado</span>
                                    <?php else: ?> 
                                    <span class="badge bg-danger">Pendiente Asig.</span>
                                    <?php endif; ?>
                                </td>
                                
                            </tr>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
    </div>    
    <!-- Basic Tables start -->
    <div class="row" id="basic-table">
        <div class="col-12">
            <div class="card p-1">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered dt-responsive table-sm" id="solicitudes">
                        <thead class="text-center">
                            <tr>
                                
                                
                                <th style="font-size: 10px">FECHA <br> TRASLADO</th>
                                <th style="font-size: 10px">CLIENTE</th>
                                <th style="font-size: 10px">HORA <br> EN GRANJA</th>
                                <th style="font-size: 10px">CANTIDAD <br> TOTAL</th>
                                <th style="font-size: 10px">ORIGEN</th>
                                <th style="font-size: 10px;width: 40px">DESTINOS</th>
                                
                                <th style="font-size: 10px;width: 40px">ASIGNAR</th>
                                <th style="font-size: 10px;width: 40px">UNIDAD</th>
                                <th style="font-size: 10px;width: 40px">PLACA</th>
                                <th style="font-size: 10px;width: 40px">CHOFER</th>
                                <th style="font-size: 10px;width: 40px">AYUDANTE</th>
                                
                                <th style="font-size: 10px">HORA <br> EN COCHERA</th>
                                <th style="font-size: 10px">ESTADO</th>
                                <th style="font-size: 10px">ACCIONES</th>

                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr style="font-size: 12px;"> 
                                
                                <?php
                                $fecha= $doc->fecha_traslado;
                                $date = new DateTime($fecha);    
                                ?>
                                <td><strong><?php echo e($date->format('d-m-Y')); ?></strong></td>
                                <td style="font-size: 12px"><strong><?php echo e($doc->nombre_cli); ?></strong></td>
                                <td><strong><?php echo e($doc->hora); ?></strong></td>
                                <td><?php echo e($doc->cantidad); ?></td>
                                <td><?php echo e($doc->referencia_cli); ?></td>
                               
                                <td> 
                                    <?php $__currentLoopData = json_decode($doc->destinos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($des->id==$item): ?>
                                        <?php echo e($des->referencia); ?> <br>
                                       
                                        <?php else: ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    ?>
                                </td>
                                
                               <td>
                                <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                    <a type="button" class="btn  btn-icon rounded-circle
                                    btn-success waves-effect waves-float waves-light"
                                    href="<?php echo e(route('enviar_info_conductor',$doc->id)); ?>">
                                    <i data-feather='phone'></i> </a>
                                    <a type="button" class="btn btn-icon btn-icon rounded-circle btn-flat-success waves-effect"
                                    data-bs-toggle="modal" data-bs-target="#editmodal<?php echo e($doc->id); ?>">
                                    <i data-feather='edit'> </i></a>
                                <?php elseif($doc->estado==2): ?> 
                                    
                                <?php else: ?>
                                    <button type="button" class="btn btn-secondary btn-icon rounded-circle"
                                    data-bs-toggle="modal" data-bs-target="#crearmodal<?php echo e($doc->id); ?>">
                                    <i data-feather='plus'></i>
                                    </button>
                                <?php endif; ?>
                               </td>
                                    <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                        <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($pla->id ==$doc->id_plani): ?>
                                                    <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($uni->id==$pla->id_unidad): ?>
                                                        
                                                       <td>  <?php echo e($uni->unidad); ?> </td>
                                                       <td>  <?php echo e($uni->placa); ?> </td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($ch->id==$pla->id_chofer): ?>
                                                          <td>  <?php echo e($ch->nombres_cho); ?> <br> <?php echo e($ch->apellidos_cho); ?></td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <?php endif; ?>
                                <td>
                                    <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                        <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($pla->id ==$doc->id_plani): ?>
                                                        <?php $__currentLoopData = $ayudantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ayu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                            <?php if($ayu->id==$pla->choferes): ?>
                                                            <?php echo e($ayu->nombres_cho); ?> <?php echo e($ayu->apellidos_cho); ?>

                                                            <?php else: ?>
                                                            <?php endif; ?>
                                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    - <strong><?php echo e($pla->tipo_des); ?></strong>
                                            <?php else: ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    -
                                    <?php endif; ?>
                                </td>
                                
                                <td><?php echo e($doc->hora_cochera); ?></td>
                                <td>
                                    <?php if($doc->estado==1): ?>
                                    <span class="badge bg-danger">Creado</span>
                                    <?php elseif($doc->estado==3): ?>
                                    <span class="badge bg-warning">Confirmado</span>
                                    <?php elseif($doc->estado==4): ?>
                                    <span class="badge bg-info">Finalizado</span>
                                    <?php elseif($doc->estado==5): ?>
                                    <span class="badge bg-primary">Facturado</span>
                                    <?php else: ?> 
                                    <span class="badge bg-danger">Pendiente Asig.</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <div class="col-lg-6 col-12">
                                        <div class="btn-group" role="group" aria-label="Basic example">
                                               
                                                <a type="button" class="btn btn-icon btn-warning waves-effect waves-float
                                                waves-light" href="<?php echo e(route('admin.solicitudes.editar',$doc->id)); ?>">
                                                <i data-feather='edit'> </i></a>
                                                <a type="button" class="btn btn-icon btn-danger waves-effect waves-float waves-light"
                                                data-bs-toggle="modal" data-bs-target="#eli<?php echo e($doc->id); ?>">
                                                    <i data-feather='trash-2'></i></a>
                                          </div>
                                    </div>
                                </td>
                            </tr>
                            <?php echo $__env->make('admin.modals.EliSoli', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.CrearPlani', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.EditPlani', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.CrearCierre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.DetCierre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    
    

    <!-- Basic Tables end -->
    <?php elseif(Auth::user()->tipo==3): ?>
     <!-- Basic Tables start -->
     <div class="row" id="basic-table">
        <div class="col-12">
            <div class="card p-1">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered dt-responsive table-sm" id="solicitudes2">
                        <thead class="text-center">
                            <tr>
                                
                                
                                <th style="font-size: 10px;width: 40px">FECHA <br> TRASLADO</th>
                                <th style="width: 40px">CLIENTE</th>
                                <th style="font-size: 10px; width: 30px">HORA <br> EN GRANJA</th>
                                <th style="font-size: 10px; width: 20px">CANT<br> Des 1</th>
                                <th style="font-size: 10px; width: 20px">CANT <br> Des 2</th>
                                <th style="font-size: 10px; width: 20px">CANT <br> Des 3</th>
                                <th style="font-size: 10px; width: 20px">CANT <br> Des 4</th>
                                <th style="width: 20px">ORIGEN</th>
                                <th style="width: 40px">DESTINOS</th>
                                
                                <th style="width: 40px">UNIDAD</th>
                                <th style="width: 40px">PLACA</th>
                                <th style="width: 40px">CHOFER</th>
                                
                                <th style="font-size: 10px;width: 40px">INDICACIONES<br> ESPECIALES</th>
                                <th style="width: 40px">ASIG</th>
                                
                                <th style="font-size: 10px;width: 40px">GUÍAS DE <br> TRANSPORTISTA</th>
                                <th style="font-size: 10px;width: 40px">GUÍAS DE <br> CLIENTE</th>
                                <th style="width: 40px">ESTADO</th>

                                
                                
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr style="font-size: 12px;"> 
                                
                                <?php
                                $fecha= $doc->fecha_traslado;
                                $date = new DateTime($fecha);    
                                ?>
                                <td><strong><?php echo e($date->format('d-m-Y')); ?></strong></td>
                                <td style="font-size: 12px"><strong><?php echo e($doc->nombre_cli); ?></strong></td>
                                <td><strong><?php echo e($doc->hora); ?></strong></td>
                                <?php
                                $datos_destinos2 = json_decode($doc->destinos, true);   
                                $datos_cantidad2 = json_decode($doc->datos_cantidad, true);   
                               $cont = count($datos_destinos2);
                                ?>
                                
                                <?php for($i=0; $i<count($datos_destinos2); $i++): ?>
                                
                                <td style="font-size: 10px;">
                                    <strong>
                                        <?php $__currentLoopData = $datos_cantidad2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($valor[$i]==0): ?>
                                            <?php else: ?>
                                                <?php if($key!== 'sub'): ?>
                                                    <?php if($key=='cant1'): ?>
                                                    <?php echo e($valor[$i]); ?>

                                                    <?php else: ?>
                                                    + <?php echo e($valor[$i]); ?>

                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </strong>
                                </td> 
                              <?php endfor; ?> 
                              <?php
                               $new = 4- $cont;
                              ?>
                              <?php for($i = 0; $i < $new; $i++): ?>
                                <td></td>
                              <?php endfor; ?>

                                
                                <td><?php echo e($doc->referencia_cli); ?></td>
                               
                                <td> 
                                    <?php $__currentLoopData = json_decode($doc->destinos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($des->id==$item): ?>
                                        <?php echo e($des->referencia); ?> <br>
                                       
                                        <?php else: ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    ?>
                                </td>
                                    <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                        <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($pla->id ==$doc->id_plani): ?>
                                                    <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($uni->id==$pla->id_unidad): ?>
                                                        
                                                       <td>  <?php echo e($uni->unidad); ?> </td>
                                                       <td>  <?php echo e($uni->placa); ?> </td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($ch->id==$pla->id_chofer): ?>
                                                          <td>  <?php echo e($ch->nombres_cho); ?> <br> <?php echo e($ch->apellidos_cho); ?></td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <td><?php echo e($pla->observaciones); ?></td>
                                                <?php else: ?>
                                                <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <td></td>

                                    <?php endif; ?>
                                <td>
                                    <?php if($doc->estado==3): ?> 
                                        <button type="button" class="btn btn-secondary btn-icon rounded-circle"
                                        data-bs-toggle="modal" data-bs-target="#crearcierre<?php echo e($doc->id); ?>">
                                        <i data-feather='plus'></i>
                                        </button>
                                        <?php elseif($doc->estado==4 || $doc->estado==5): ?> 
                                        <button type="button" class="btn btn-danger btn-icon rounded-circle"
                                        data-bs-toggle="modal" data-bs-target="#detcierre<?php echo e($doc->id); ?>">
                                        <i data-feather='download-cloud'></i>
                                        </button>
                                        <?php else: ?>
                                        <button type="button" class="btn btn-outline-secondary btn-icon rounded-circle" 
                                        data-bs-toggle="modal" data-bs-target="#crearcierre<?php echo e($doc->id); ?>" disabled>
                                        <i data-feather='plus'></i>
                                        </button>
                                        <?php endif; ?>
                                </td>
                                
                                <?php if($doc->estado==4 || $doc->estado==5): ?>
                                    <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <?php if($doc->id_cierre==$item->id): ?>
                                                              <?php
                                                            $datos_n_guias = json_decode($item->n_guias, true);
                                                            $datos_n_remision = json_decode($item->n_remision, true);
                                                        //    $fecha = $item->indicaciones;
                                                           ?>
                                                <td>
                                                    <?php $__currentLoopData = $datos_n_guias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item); ?> <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $datos_n_remision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item2); ?> <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                                
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <td></td>
                                <td></td>
                                <?php endif; ?>
                                
                                <td>
                                    <?php if($doc->estado==1): ?>
                                    <span class="badge bg-danger">Creado</span>
                                    <?php elseif($doc->estado==3): ?>
                                    <span class="badge bg-warning">Confirmado</span>
                                    <?php elseif($doc->estado==4): ?>
                                    <span class="badge bg-info">Finalizado</span>
                                    <?php elseif($doc->estado==5): ?>
                                    <span class="badge bg-primary">Facturado</span>
                                    <?php else: ?> 
                                    <span class="badge bg-danger">Pendiente Asig.</span>
                                    <?php endif; ?>
                                </td>
                                
                                
                            </tr>
                            <?php echo $__env->make('admin.modals.CrearPlani', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.EditPlani', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.CrearCierre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.DetCierre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                           
                           
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Basic Tables end -->
    <?php elseif(Auth::user()->tipo==4): ?>
    <!-- Basic Tables start -->
    <div class="row" id="basic-table">
        <div class="col-12">
            <div class="card p-1">
                <div class="table-responsive">
                    <table class="table table-striped table-bordered table-sm" id="solicitudes3">
                        <thead class="text-center">
                            <tr >
                                
                                
                                <th style="font-size: 10px;width: 40px">FECHA <br> TRASLADO</th>
                                <th style="font-size: 10px;width: 40px">CLIENTE</th>
                                <th style="font-size: 10px; width: 30px">HORA <br> EN GRANJA</th>
                                <th style="font-size: 10px; width: 20px">CANT<br> Des 1</th>
                                <th style="font-size: 10px; width: 20px">CANT <br> Des 2</th>
                                <th style="font-size: 10px; width: 20px">CANT <br> Des 3</th>
                                <th style="font-size: 10px; width: 20px">CANT <br> Des 4</th>
                                <th style="font-size: 10px;width: 20px">ORIGEN</th>
                                <th style="font-size: 10px;width: 40px">DESTINOS</th>
                                
                                <th style="font-size: 10px;width: 40px">UNi.</th>
                                <th style="font-size: 10px;width: 40px">PLACA</th>
                                <th style="font-size: 10px;width: 40px">CHOFER</th>
                               
                                
                                <th style="font-size: 10px;width: 40px">GUÍAS DE <br> TRANSP.</th>
                                <th style="font-size: 10px;width: 40px">GUÍAS DE <br> CLIENTE</th>
                                <th style="font-size: 10px;width: 40px">COSTO FLETE</th>
                                <th style="font-size: 8px;width: 20px">FECHA DE <br> FACTURACIÓN</th>
                                <th style="font-size: 8px;width: 20px">N° FACTURACIÓN</th>
                                <th style="font-size: 10px;width: 40px">ESTADO</th>
                                <th>ACCIONES</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $solicitudes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            
                            <tr style="font-size: 12px;"> 
                                
                                <?php
                                $fecha= $doc->fecha_traslado;
                                $date = new DateTime($fecha);    
                                ?>
                                <td><strong><?php echo e($date->format('d-m-Y')); ?></strong></td>
                                <td style="font-size: 12px"><strong><?php echo e($doc->nombre_cli); ?></strong></td>
                                <td><strong><?php echo e($doc->hora); ?></strong></td>
                                <?php
                                $datos_destinos2 = json_decode($doc->destinos, true);   
                                $datos_cantidad2 = json_decode($doc->datos_cantidad, true);   
                               $cont = count($datos_destinos2);
                                ?>
                                
                                <?php for($i=0; $i<count($datos_destinos2); $i++): ?>
                                
                                <td>
                                    <strong>
                                        <?php $__currentLoopData = $datos_cantidad2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $valor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($valor[$i]==0): ?>
                                            <?php else: ?>
                                                <?php if($key!== 'sub'): ?>
                                                    <?php if($key=='cant1'): ?>
                                                    <?php echo e($valor[$i]); ?>

                                                    <?php else: ?>
                                                    + <?php echo e($valor[$i]); ?>

                                                    <?php endif; ?>
                                                <?php endif; ?>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </strong>
                                </td> 
                              <?php endfor; ?> 
                              <?php
                               $new = 4- $cont;
                              ?>
                              <?php for($i = 0; $i < $new; $i++): ?>
                                <td></td>
                              <?php endfor; ?>

                                
                                <td><?php echo e($doc->referencia_cli); ?></td>
                               
                                <td> 
                                    <?php $__currentLoopData = json_decode($doc->destinos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php $__currentLoopData = $destinos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $des): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($des->id==$item): ?>
                                        <?php echo e($des->referencia); ?> <br>
                                       
                                        <?php else: ?>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php
                                    ?>
                                </td>
                                    <?php if($doc->estado==3 || $doc->estado==4 || $doc->estado==5): ?> 
                                        <?php $__currentLoopData = $planificaciones; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pla): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($pla->id ==$doc->id_plani): ?>
                                                    <?php $__currentLoopData = $vehiculos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $uni): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if($uni->id==$pla->id_unidad): ?>
                                                        
                                                       <td>  <?php echo e($uni->unidad); ?> </td>
                                                       <td>  <?php echo e($uni->placa); ?> </td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                    <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php if($ch->id==$pla->id_chofer): ?>
                                                          <td>  <?php echo e($ch->nombres_cho); ?> <br> <?php echo e($ch->apellidos_cho); ?></td>
                                                        <?php else: ?>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                <?php else: ?>
                                                <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <td></td>
                                    <td></td>
                                    <td></td>
                                    <?php endif; ?>
                                
                                
                                <?php if($doc->estado==4 || $doc->estado==5): ?>
                                    <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    
                                        <?php if($doc->id_cierre==$item->id): ?>
                                                           <?php
                                                            $datos_n_guias = json_decode($item->n_guias, true);
                                                            $datos_n_remision = json_decode($item->n_remision, true);
                                                            ?>
                                                <td>
                                                    <?php $__currentLoopData = $datos_n_guias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item); ?> <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></td>
                                                <td>
                                                    <?php $__currentLoopData = $datos_n_remision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <?php echo e($item2); ?> <br>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </td>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                <td></td>
                                <td></td>
                                <?php endif; ?>
                                <td><?php echo e($doc->costo); ?></td>
                                
                                    <?php if($doc->estado==4): ?>
                                    <td>
                                        <button type="button" class="btn btn-secondary btn-icon rounded-circle"
                                                    data-bs-toggle="modal" data-bs-target="#editcierre<?php echo e($doc->id); ?>">
                                                    <i data-feather='plus'></i>
                                        </button>
                                    </td>
                                    <td></td>
                                    <?php elseif($doc->estado==5): ?>
                                        <?php $__currentLoopData = $cierres; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($doc->id_cierre==$item->id): ?>
                                                    <td> <?php echo e($item->fecha_fac); ?></td>
                                                    <td> <?php echo e($item->n_fac); ?></td>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    <?php else: ?>
                                    <td> <button type="button" class="btn btn-secondary btn-icon rounded-circle"
                                        data-bs-toggle="modal" data-bs-target="#editcierre<?php echo e($doc->id); ?>" disabled>
                                        <i data-feather='plus'></i>
                            </button>
                        </td>
                                    <td></td>
                                    <?php endif; ?>
                                <td>
                                    <?php if($doc->estado==1): ?>
                                    <span class="badge bg-danger">Creado</span>
                                    <?php elseif($doc->estado==3): ?>
                                    <span class="badge bg-warning">Confirmado</span>
                                    <?php elseif($doc->estado==4): ?>
                                    <span class="badge bg-info">Finalizado</span>
                                    <?php elseif($doc->estado==5): ?>
                                    <span class="badge bg-primary">Facturado</span>
                                    <?php else: ?> 
                                    <span class="badge bg-danger">Pendiente Asig.</span>
                                    <?php endif; ?>
                                </td>
                                <td>
                                    <?php if($doc->estado==5): ?>
                                    <button type="button" class="btn btn-secondary btn-icon rounded-circle"
                                    data-bs-toggle="modal" data-bs-target="#editcierre2<?php echo e($doc->id); ?>">
                                    <i data-feather='edit'></i>
                                </button> 
                                    <?php else: ?>
                                    <button type="button" class="btn btn-secondary btn-icon rounded-circle"
                                  disabled>
                                    <i data-feather='edit'></i>
                                </button> 
                                    <?php endif; ?>
                                    
                                </td>
                            </tr>
                            <?php echo $__env->make('admin.modals.ActualizarCierre', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php echo $__env->make('admin.modals.ActualizarCierre2', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Basic Tables end -->
    <?php else: ?>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php if(session()->get('data')): ?>
<div class="alert alert-success">
    <script>
       var text = '<?php echo e(session()->get('data')); ?>';
       Swal.fire(
        'Ok!',
        text,
        'success'
        )       
    </script>
</div>
<?php endif; ?>
  <script>

$( function() {
    $("#ayudantes").change( function() {
        if ($(this).val() !== "") {
            $("#carga").prop("disabled", false);
            $("#descarga").prop("disabled", false);
            $("#descarga2").prop("disabled", false);
        } else {
            $("#carga").prop("disabled", true);
            $("#descarga").prop("disabled", true);
            $("#descarga2").prop("disabled", true);
        }
    });
});

    var idioma=

{
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "NingÃºn dato disponible en esta tabla",
    "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
    "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Ãšltimo",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    },
    "buttons": {
        "copyTitle": 'Informacion copiada',
        "copyKeys": 'Use your keyboard or menu to select the copy command',
        "copySuccess": {
            "_": '%d filas copiadas al portapapeles',
            "1": '1 fila copiada al portapapeles'
        },

        "pageLength": {
        "_": "Mostrar %d filas",
        "-1": "Mostrar Todo"
        }
    }
};

//Convierte el div a imagen y la descarga
document.querySelector('button').addEventListener('click', function() {
  
});


$('#unidad').on('change', function(){
       
       var id = $(this).val();
       // alert(id);
       // alert(id);
           $.ajax({
           url:'<?php echo e(route('buscarunidad')); ?>',
           type:'GET',
           data:{'id':id},
           dataType:'json',
           success:function (data) {
               console.log(data);
               // $('#product_list').html(data);
               $('#datos_unidad').val(data);
               // alert(data.table_data);
           }
       })
   });

   $('#chofer').on('change', function(){

var id = $(this).val();
// alert(id);
// alert(id);
  $.ajax({
  url:'<?php echo e(route('buscarchofer')); ?>',
  type:'GET',
  data:{'id':id},
  dataType:'json',
  success:function (data) {
      console.log(data);
      // $('#product_list').html(data);
      $('#datos_chofer').val(data);
      // alert(data.table_data);
  }
})
});


var idioma=

        {
            "sProcessing":     "Procesando...",
            "sLengthMenu":     "Mostrar _MENU_ registros",
            "sZeroRecords":    "No se encontraron resultados",
            "sEmptyTable":     "NingÃºn dato disponible en esta tabla",
            "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix":    "",
            "sSearch":         "Buscar:",
            "sUrl":            "",
            "sInfoThousands":  ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst":    "Primero",
                "sLast":     "Ãšltimo",
                "sNext":     "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            },
            "buttons": {
                "copyTitle": 'Informacion copiada',
                "copyKeys": 'Use your keyboard or menu to select the copy command',
                "copySuccess": {
                    "_": '%d filas copiadas al portapapeles',
                    "1": '1 fila copiada al portapapeles'
                },

                "pageLength": {
                "_": "Mostrar %d filas",
                "-1": "Mostrar Todo"
                }
            }
        };
        var idioma2=

{
    "sProcessing":     "Procesando...",
    "sLengthMenu":     "Mostrar _MENU_ registros",
    "sZeroRecords":    "No se encontraron resultados",
    "sEmptyTable":     "NingÃºn dato disponible en esta tabla",
    "sInfo":           "",
    "sInfoEmpty":      "",
    "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
    "sInfoPostFix":    "",
    "sSearch":         "Buscar:",
    "sUrl":            "",
    "sInfoThousands":  ",",
    "sLoadingRecords": "Cargando...",
    "oPaginate": {
        "sFirst":    "Primero",
        "sLast":     "Ãšltimo",
        "sNext":     "Siguiente",
        "sPrevious": "Anterior"
    },
    "oAria": {
        "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
        "sSortDescending": ": Activar para ordenar la columna de manera descendente"
    },
    "buttons": {
        "copyTitle": 'Informacion copiada',
        "copyKeys": 'Use your keyboard or menu to select the copy command',
        "copySuccess": {
            "_": '%d filas copiadas al portapapeles',
            "1": '1 fila copiada al portapapeles'
        },

        "pageLength": {
        "_": "Mostrar %d filas",
        "-1": "Mostrar Todo"
        }
    }
};

        $(document).ready( function () {
        var table = $('#solicitudes').DataTable({
                    dom: '<"border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
                    language: idioma,
                    buttons: [
                    // 'excel'
                        {
                        extend: 'excel',
                        text: feather.icons['file'].toSvg({ class: 'font-small-4 me-50' }) + 'Excel',
                        className: 'btn btn-sm btn-info round waves-effect',
                        exportOptions: { columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12] }
                        },
                        {
                            extend: 'print',
                        text: feather.icons['printer'].toSvg({ class: 'font-small-4 me-50' }) + 'Print',
                        className: 'btn btn-sm btn-info round waves-effect',
                        exportOptions: { columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12] }
                        },
                    ],
                    "order": [[ 0, 'desc' ], [ 2, 'asc' ]],
                    exportOptions: {
                    modifier: {
                    // DataTables core
                    // 'current', 'applied',
                    //'index', 'original'
                    page: 'all', // 'all', 'current'
                    search: 'none' // 'none', 'applied', 'removed'
                    },
                        columns: [0,1, 2, 3, 4, 5, 6, 7, 8,9,10,11,12]
                        
                    }
                })

        } );
        $(document).ready( function () {
        var table = $('#tablamaestro').DataTable({
                    dom:'Brt<"col-md-6 inline"i> <"col-md-6 inline">',
                    language: idioma2,
                    buttons: [
                    // 'excel'
                        {
                        extend: 'excel',
                        text: feather.icons['file'].toSvg({ class: 'font-small-4 me-50' }) + 'Excel Maestro',
                        className: 'btn btn-sm btn-success round waves-effect',
                        exportOptions: { columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12] }
                        }

                    ],
                    "order": [[ 0, 'desc' ], [ 2, 'asc' ]],
                    exportOptions: {
                    modifier: {
                    // DataTables core
                    // 'current', 'applied',
                    //'index', 'original'
                    page: 'all', // 'all', 'current'
                    search: 'none' // 'none', 'applied', 'removed'
                    },
                        columns: [0,1, 2, 3, 4, 5, 6, 7, 8,9,10,11,12]
                        
                    }
                })

        } );

        $(document).ready( function () {
        var table = $('#solicitudes2').DataTable({
                    dom: '<"border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
                    language: idioma,
                    buttons: [
                    // 'excel'
                        {
                        extend: 'excel',
                        text: feather.icons['file'].toSvg({ class: 'font-small-4 me-50' }) + 'Excel',
                        className: 'btn btn-sm btn-info round waves-effect',
                        exportOptions: { columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12,13,14,15,16] }
                        },
                        {
                            extend: 'print',
                        text: feather.icons['printer'].toSvg({ class: 'font-small-4 me-50' }) + 'Print',
                        className: 'btn btn-sm btn-info round waves-effect',
                        exportOptions: { columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12,13,14,15,16] }
                        },
                    ],
                    "order": [[ 0, 'desc' ], [ 2, 'asc' ]],
                    exportOptions: {
                    modifier: {
                    // DataTables core
                    // 'current', 'applied',
                    //'index', 'original'
                    page: 'all', // 'all', 'current'
                    search: 'none' // 'none', 'applied', 'removed'
                    },
                        columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12,13,14,15,16]
                        
                    }
                })

        } );
        $(document).ready( function () {
        var table = $('#solicitudes3').DataTable({
                    dom: '<"border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',
                    language: idioma,
                    buttons: [
                    // 'excel'
                        {
                        extend: 'excel',
                        text: feather.icons['file'].toSvg({ class: 'font-small-4 me-50' }) + 'Excel',
                        className: 'btn btn-sm btn-info round waves-effect',
                        exportOptions: { columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12] }
                        },
                        {
                            extend: 'print',
                        text: feather.icons['printer'].toSvg({ class: 'font-small-4 me-50' }) + 'Print',
                        className: 'btn btn-sm btn-info round waves-effect',
                        exportOptions: { columns: [0,1,2,3, 4, 5, 6,7,8,9,10,11,12] }
                        },
                    ],
                    "order": [[ 4, 'asc' ], [ 5, 'asc' ]],
                    exportOptions: {
                    modifier: {
                    // DataTables core
                    // 'current', 'applied',
                    //'index', 'original'
                    page: 'all', // 'all', 'current'
                    search: 'none' // 'none', 'applied', 'removed'
                    },
                        columns: [0,1, 2, 3, 4, 5, 6, 7, 8,9,10,11,12]
                        
                    }
                })

        } );
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\tranzales2\resources\views/admin/solicitudes/index.blade.php ENDPATH**/ ?>