<div class="modal fade" id="eli<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Eliminar Tarifa</h5>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
          </button>
      </div>
      <div class="modal-body">
          <form action="<?php echo e(route('delete-tarifa',$doc->id)); ?>" method="post">
              <?php echo csrf_field(); ?>
              <?php echo method_field('delete'); ?>
                  <div class="text-center">
                      <h4 class="mb-1 text-danger">¿Desea eliminar esta tarifa?</h4>
                      <p class="card-text m-auto w-75">
                        
                      </p>
                  </div>
       </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        <button type="submit" class="btn btn-danger me-1 waves-effect waves-float waves-light">Eliminar</button>

      </div>
  </form>
    </div>
  </div>
</div>
<?php /**PATH C:\xampp\htdocs\tranzales\resources\views/admin/modals/modalelitari.blade.php ENDPATH**/ ?>