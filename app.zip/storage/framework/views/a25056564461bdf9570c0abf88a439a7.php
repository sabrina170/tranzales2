<div class="modal fade" id="detviatico<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-dialog-scrollable modal-lg" >
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalScrollableTitle">Detalle Viaticos - Personal</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <form  method="post" enctype="multipart/form-data">
            <div class="modal-body">
                    <div class="row">
                        <?php $__currentLoopData = $viaticos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php if($item->id==$doc->id_viaticos): ?>
                            <div class="col-md-12">
                                    <div class="d-flex align-items-center">
                                        <div class="col-6"></div>
                                        <div class="col-6">
                                            <div class="row p-0">
                                                <div class="col-sm-6">
                                                    <label class="col-form-label" for="first-name">
                                                        COSTO TOTAL VIATICO PERSONAL</label>
                                                </div>
                                                <div class="col-sm-6">
                                                    <input type="number" class="form-control" 
                                                    name="costo_total" value="<?php echo e($item->costo_total); ?>" placeholder="100.00" disabled>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                            </div>
                            <div class="col-md-4 p-1 border">
                                <label class="form-label" for="select2-basic">MOVILIDAD (S/.)</label>
                                <div class="mb-1">
                                <input type="number" name="movilidad" class="form-control "
                                            placeholder="100" value="<?php echo e($item->movilidad); ?>" step="any" disabled>
                                </div>
                                <label class="form-label" for="select2-basic">ALIMENTO (S/.)</label>
                                <div class="mb-1">
                                <input type="number" name="alimento" class="form-control "
                                            placeholder="100"  value="<?php echo e($item->alimento); ?>" step="any" disabled>
                                </div>
                                <label class="form-label" for="select2-basic">SERVICIO / APOYO (S/.)</label>
                                <div class="mb-1">
                                <input type="number" name="servicio" class="form-control "
                                            placeholder="100"  value="<?php echo e($item->servicio); ?>"  step="any" disabled>
                                </div> 
                            </div>
                            <div class="col-md-4 p-1 border">
                                <label class="form-label" for="select2-basic">MOTIVO</label>
                                <div class="mb-1">
                                <p><strong><?php echo e($item->motivo_mo); ?></strong></p>
                                </div>
                                <label class="form-label" for="select2-basic">MOTIVO</label>
                                <div class="mb-1">
                                <p><strong><?php echo e($item->motivo_ali); ?></strong></p>
                                </div>
                                <label class="form-label" for="select2-basic">MOTIVO</label>
                                <div class="mb-1">
                                <p><strong><?php echo e($item->motivo_ser); ?></strong></p>

                                </div>
                            </div>
                            <div class="col-md-4 p-1 border">
                                <label class="form-label mb-1" for="select2-basic">ORIGEN DE TRANSICIÓN</label>
                                
                                <div class="mb-1">
                                    <?php if($item->origen=="EMPRESA"): ?>
                                    <p><strong class="form-check-label" for="exampleRadios1">
                                        EMPRESA
                                        </strong></p>
                                    <?php elseif($item->origen=="CONDUCTOR"): ?>
                                    <p><strong class="form-check-label" for="exampleRadios2">
                                        CONDUCTOR
                                    </strong></p>
                                    <?php else: ?>
                                    <p><strong class="form-check-label" for="exampleRadios3">
                                        TERCERO
                                    </strong></p>
                                    <?php endif; ?>
                                </div>  
                                    
                            </div>
                            <div class="mb-1 mt-1">
                                <label class="d-block form-label"
                                for="validationBioBootstrap">OBSERVACIONES</label>
                                <p>
                                    <?php echo e($item->observaciones); ?>

                                </p>
                            </div>
                        <?php else: ?>
                        <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    
            </div>

    
            </form>
        </div>
    </div>
</div>
<?php /**PATH /home4/capacjc2/public_html/transporte_gonzales/resources/views/admin/modals/DetViatico.blade.php ENDPATH**/ ?>