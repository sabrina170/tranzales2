<!-- MENU -->
<?php $__env->startSection('content'); ?>

<div class="content-header row">
    <div class="content-header-left col-md-9 col-12 mb-2">
        <div class="row breadcrumbs-top">
            <div class="col-12">
                <h2 class="content-header-title float-start mb-0">Modulo</h2>
                <div class="breadcrumb-wrapper">
                    <ol class="breadcrumb">
                        <li class="breadcrumb-item"><a href="#">Choferes y Ayudantes</a>
                        </li>
                    </ol>
                </div>
            </div>
        </div>
    </div>
    
</div>
<div class="content-body">
    <section class="app-user-list">

        <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#exampleModal">
           + Agregar
          </button> 
          <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Agregar Vehiculo</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            </button>
        </div>
        <div class="modal-body">
            <form action="<?php echo e(route('crear-chofer')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="row">
                    
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="first-name-column">Unidades</label>
                            <select class="form-select" id="basicSelect" name="tipo_cho" required>
                                <option value="1">Chofer</option>
                                <option value="2">Ayudante</option>
                            </select>
                        </div>
                    </div>
                    
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="country-floating">Nombres</label>
                            <input type="text" id="country-floating" class="form-control" name="nombres_cho"
                             placeholder="nombres" required>
                        </div>
                    </div>
                    <div class="col-md-6 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="country-floating">Apellidos</label>
                            <input type="text" id="country-floating" class="form-control" name="apellidos_cho"
                             placeholder="apellidos" required>
                        </div>
                    </div>
                    <div class="col-md-4 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="last-name-column">Celular</label>
                            <input type="number" id="last-name-column" class="form-control" placeholder="987912321" name="celular_cho" required>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="country-floating">DNI/CELULA</label>
                            <input type="number" id="last-name-column" class="form-control" placeholder="76232414" name="dni_cho" required>
                            
                        </div>
                    </div>
                    <div class="col-md-5 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="first-name-column">Adjuntar</label>
                            <input type="file" id="first-name-column" class="form-control" name="dni_doc" required>
                        </div>
                    </div>
                    <div class="col-md-4 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="city-column">Brevete</label>
                            <input type="text" id="city-column" class="form-control" placeholder="AKJ888" name="brevete_cho" required>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="country-floating">Tipo de contrato</label>
                             <select class="form-select" id="basicSelect" name="tipo_contrato" required>
                                <option value="1">RR.HH</option>
                                <option value="2">Planilla</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-5 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="first-name-column">Adjuntar</label>
                            <input type="file" id="first-name-column" class="form-control" name="contrato_doc" required>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="city-column">Telefono Emergencia</label>
                            <input type="text" id="city-column" class="form-control" placeholder="AKJ888" name="telefono_emer" required>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="company-column">Duración de contrato</label>
                            <input type="text" id="company-column" class="form-control" name="duracion_contrato"
                             placeholder="6 meses/1 año" required>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="email-id-column">Fecha Inicio</label>
                            <input type="date" id="email-id-column" class="form-control" name="fecha_inicio"  required>
                        </div>
                    </div>
                    <div class="col-md-3 col-12">
                        <div class="mb-1">
                            <label class="form-label" for="company-column">Fecha Vencimiento Brevete</label>
                            <input type="date" id="company-column" class="form-control" name="fecha_ven_cho" required>
                        </div>
                    </div>
                </div>
         </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
          <button type="submit" class="btn btn-danger me-1 waves-effect waves-float waves-light">Agregar</button>

        </div>
    </form>
      </div>
    </div>
  </div>
        
         <!-- Basic Tables start -->
    <div class="row mt-2" id="basic-table">
        <div class="col-12">
            <div class="card p-1">
                
               
                <div class="table-responsive">
                    <table class="table" id="postulantes">
                        <thead>
                            <tr>
                                
                                <th>Nombres y Apellidos</th>
                                <th>Telefono</th>
                                <th>Brevete</th>
                                <th>Fecha Ven. Brevete</th>
                                <th>DNI</th>
                                <th>Tipo de Contrato</th>
                                <!--<th>Telefono de Emergencia</th>-->
                                <th>Fecha Creación</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $choferes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $doc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr> 
                                <td> <?php echo e($doc->nombres_cho); ?> <?php echo e($doc->apellidos_cho); ?> </td>
                                <td><?php echo e($doc->celular_cho); ?></td>
                                <td><?php echo e($doc->brevete_cho); ?> </td>
                                <td><?php echo e($doc->fecha_ven_cho); ?> </td>
                                <td><?php echo e($doc->dni_cho); ?> </td>
                                <td>
                                    <?php if($doc->tipo_contrato==1): ?>
                                        <strong>RR.HH</strong>
                                    <?php else: ?>
                                    <strong>PLANILLA</strong>
                                    <?php endif; ?>
                                    </td>
                                <!--<td><?php echo e($doc->telefono_emer); ?></td>-->
                                <td><?php echo e($doc->created_at); ?></td>
                                <td>
                                    <div class="btn-group" role="group" aria-label="Basic example">
                                    <a type="button" class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#view<?php echo e($doc->id); ?>"><i data-feather='eye'></i></a>
                                    
                                    </div>
                                </td>
                            </tr>
                            <?php echo $__env->make('admin.modals.modaldetchofer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
    <!-- Basic Tables end -->
       
    </section>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<?php if(session()->get('data')): ?>
<div class="alert alert-success">
    <script>
       var text = '<?php echo e(session()->get('data')); ?>';
        Swal.fire(
        'Creado!',
        text,
        'success'
        )
    </script>
</div>
<?php endif; ?>
<script>
        var idioma=
         {
            "sProcessing":     "Procesando...",
            "sLengthMenu":     "Mostrar _MENU_ registros",
            "sZeroRecords":    "No se encontraron resultados",
            "sEmptyTable":     "NingÃºn dato disponible en esta tabla",
            "sInfo":           "Mostrando registros del _START_ al _END_ de un total de _TOTAL_ registros",
            "sInfoEmpty":      "Mostrando registros del 0 al 0 de un total de 0 registros",
            "sInfoFiltered":   "(filtrado de un total de _MAX_ registros)",
            "sInfoPostFix":    "",
            "sSearch":         "Buscar:",
            "sUrl":            "",
            "sInfoThousands":  ",",
            "sLoadingRecords": "Cargando...",
            "oPaginate": {
                "sFirst":    "Primero",
                "sLast":     "Ãšltimo",
                "sNext":     "Siguiente",
                "sPrevious": "Anterior"
            },
            "oAria": {
                "sSortAscending":  ": Activar para ordenar la columna de manera ascendente",
                "sSortDescending": ": Activar para ordenar la columna de manera descendente"
            },
            "buttons": {
                "copyTitle": 'Informacion copiada',
                "copyKeys": 'Use your keyboard or menu to select the copy command',
                "copySuccess": {
                    "_": '%d filas copiadas al portapapeles',
                    "1": '1 fila copiada al portapapeles'
                },

                "pageLength": {
                "_": "Mostrar %d filas",
                "-1": "Mostrar Todo"
                }
            }
};
   $(document).ready(function () {
    $('#postulantes').DataTable({
        dom: '<"border-bottom p-1"<"head-label"><"dt-action-buttons text-end"B>><"d-flex justify-content-between align-items-center mx-0 row"<"col-sm-12 col-md-6"l><"col-sm-12 col-md-6"f>>t<"d-flex justify-content-between mx-0 row"<"col-sm-12 col-md-6"i><"col-sm-12 col-md-6"p>>',

        language: idioma,
        buttons: [
        // 'excel'
            {
              extend: 'excel',
              text: feather.icons['file'].toSvg({ class: 'font-small-4 me-50' }) + 'Excel',
              className: 'btn btn-sm btn-info round waves-effect',
              exportOptions: { columns: [0,1,2,3, 4, 5, 6,7] }
            },
            {
                extend: 'pdf',
              text: feather.icons['clipboard'].toSvg({ class: 'font-small-4 me-50' }) + 'Pdf',
              className: 'btn btn-sm btn-info round waves-effect',
              exportOptions: { columns: [0,1,2,3, 4, 5, 6,7] }

            },
            {
                extend: 'print',
              text: feather.icons['printer'].toSvg({ class: 'font-small-4 me-50' }) + 'Print',
              className: 'btn btn-sm btn-info round waves-effect',
              exportOptions: { columns: [0,1,2,3, 4, 5, 6,7] }

            },
    ],
    exportOptions: {
        modifier: {
          // DataTables core
          order: 'index', // 'current', 'applied',
          //'index', 'original'
          page: 'all', // 'all', 'current'
          search: 'none' // 'none', 'applied', 'removed'
        },
            columns: [0,1, 2, 3, 4, 5, 6, 7, 8]
      }
    });
});

   
</script>
<?php $__env->stopSection(); ?>

<!-- MENU -->

<?php echo $__env->make('layouts.head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home4/capacjc2/public_html/transporte_gonzales/resources/views/admin/choferes/index.blade.php ENDPATH**/ ?>