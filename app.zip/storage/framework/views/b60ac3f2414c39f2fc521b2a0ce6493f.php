<div class="modal fade" id="view<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="exampleModalLabel">Detalle Cliente</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
            </button>
        </div>
        <div class="modal-body">
          <div class="row">
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="first-name-column">Nombre</label>
                    <input type="text" id="first-name-column" class="form-control"  name="nombre" value="<?php echo e($doc->nombre); ?>" disabled>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="first-name-column">Ruc</label>
                    <input type="number" id="ruc" class="form-control"  name="ruc" value="<?php echo e($doc->ruc); ?>" disabled>
                </div>
            </div>
            <div class="col-md-4 col-12">
              <div class="mb-1">
                  <label class="form-label" for="first-name-column">Referencia</label>
                  <input type="text" id="ruc" class="form-control"  name="referencia" value="<?php echo e($doc->referencia); ?>" disabled>
              </div>
          </div>
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="last-name-column">Departamento</label>
                    <input type="text" id="ruc" class="form-control" value="<?php echo e($doc->nombre_dep); ?>" disabled>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="city-column">Provincia</label>
                    <input type="text" id="ruc" class="form-control" value="<?php echo e($doc->nombre_prov); ?>" disabled>
                </div>
            </div>
            <div class="col-md-4 col-12">
                <div class="mb-1">
                    <label class="form-label" for="country-floating">Distrito</label>
                    <input type="text" id="ruc" class="form-control" value="<?php echo e($doc->nombre_dis); ?>" disabled>
                </div>
            </div>
            <div class="col-md-6 col-12">
                <div class="mb-1">
                    <label class="form-label" for="company-column">Direccion</label>
                    <input type="text" id="ruc" class="form-control" value="<?php echo e($doc->direccion); ?>" disabled>
                </div>
            </div>
            <div class="col-md-6 col-12">
                <div class="mb-1">
                    <label class="form-label" for="company-column">Tipo de Servicio</label>
                    <br>
                    
                    <?php if($doc->tipo_servicio==1): ?>
                    <strong>GORRINOS</strong>
                    <?php elseif($doc->tipo_servicio==2): ?>
                    <strong>ALIMENTOS</strong>
                    <?php elseif($doc->tipo_servicio==3): ?>
                    <strong>LECHONES</strong>
                    <?php else: ?>
                    <strong>-</strong>
                    <?php endif; ?>
                </div>
            </div>
            <div class="col-md-12 col-12">
              <div class="mb-1">
                  <label class="form-label" for="company-column">Contactos</label>
              </div>
              
            </div> 
            
          </div>
          <div class="container text-center">
            <div class="row ">
              <div class="col badge badge-light-dark">CONTACTO</div>
              <div class="col badge badge-light-dark">TELEFONO</div>
              <div class="col badge badge-light-dark">CARGO</div>
              <div class="col badge badge-light-dark">CORREO</div>
            </div>
          </div>
          <div class="container text-center">
              <?php $__currentLoopData = json_decode($doc->contactos); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <div class="row">
                <div class="col-3"><?php echo e($item->contacto); ?></div>
                <div class="col-3"><?php echo e($item->telefono); ?></div>
                <div class="col-3"><?php echo e($item->cargo); ?></div>
                <div class="col-3"><?php echo e($item->correo); ?></div>
              </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </div>
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cerrar</button>
        </div>
      </div>
    </div>
  </div>
  <?php /**PATH C:\xampp\htdocs\tranzales\resources\views/admin/modals/modaldetcli.blade.php ENDPATH**/ ?>