<div class="modal fade" id="view<?php echo e($doc->id); ?>" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-sm" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Agregar Vehiculo</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close">
                </button>
            </div>
            <div class="modal-body">
               
                    <div class="row">
                        <div class="col-md-12 col-12 text-center">
                            <h4><?php echo e($doc->name); ?></h4>
                            <h6 class="text-muted"><?php echo e($doc->apellido_pa); ?></h6>
                            <h6 class="text-muted"> <?php echo e($doc->apellido_ma); ?></h6>
                            <?php if($doc->estado==1): ?>
                            <span class="badge badge-light-success profile-badge">Activo</span>
                            <?php else: ?>
                            <span class="badge badge-light-danger profile-badge">Inactivo</span>
                            <?php endif; ?>

                            <hr class="mb-2">
                            <p>DNI : <strong> <?php echo e($doc->dni); ?></strong></p>
                        </div>
                        <div class="col-md-12 col-12 text-center">
                            <div class="mb-1">
                                <label class="form-label fw-bolder">Usuario</label>
                                <p><?php echo e($doc->email); ?></p>
                            </div>
                            <div class="mb-1">
                                <label class="form-label fw-bolder">Contraseña</label>
                                <p><?php echo e($doc->re_password); ?></p>
                            </div>
                            <div class="mb-1">
                                <label class="form-label fw-bolder">Celular</label>
                                <p><?php echo e($doc->celular); ?></p>
                            </div>
                            <div class="mb-1">
                                <label class="form-label fw-bolder">Fecha de creación</label>
                                <p><?php echo e($doc->created_at); ?></p>
                            </div>
                        </div>
                    </div>

            </div>
        </div>
    </div>
</div><?php /**PATH C:\xampp\htdocs\tranzales2\resources\views/admin/modals/modaldetuser.blade.php ENDPATH**/ ?>